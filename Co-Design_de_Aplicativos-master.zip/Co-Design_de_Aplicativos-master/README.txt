A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/dVpPZL.

 A few cool social buttons with smooth animations. Inspired by https://dribbble.com/shots/1674790-Infinity-Icon-iOS-7